<?php 
/**
 * all file includeed
 *
 * @param  
 * @return mixed|string
 */
get_template_part('inc/class-consultup-theme-options');
get_template_part('inc/admin-function');
//theme-option
get_template_part('lib/theme-option/class-consultup-admin-settings');
